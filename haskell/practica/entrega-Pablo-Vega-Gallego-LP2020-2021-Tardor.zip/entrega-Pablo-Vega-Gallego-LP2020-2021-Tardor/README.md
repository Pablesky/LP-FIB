Per a compilar i executar el programa, basta amb fer make al terminal.
